var class_kernel =
[
    [ "Kernel", "class_kernel.html#a25ffaa0c67cc5b8c7fcdb6f97ca1725f", null ],
    [ "~Kernel", "class_kernel.html#a9c7407e3a0b1cb9b2f96e9a030187064", null ],
    [ "dot", "class_kernel.html#af258ecfb8ca0182e6a79c06291586e5b", null ],
    [ "get_Q", "class_kernel.html#a30483355cbb8b5ab4e4c7a93bcef7429", null ],
    [ "get_QD", "class_kernel.html#a5b7fde9af9d10f7b8f7105eb85bf3d5b", null ],
    [ "k_function", "class_kernel.html#a6ff0d4ac64bf7fba29d2ca3433dd5127", null ],
    [ "kernel_linear", "class_kernel.html#a9ccd52d8f291ab38be66944257420a87", null ],
    [ "kernel_poly", "class_kernel.html#af9a74728d70af7ec68947b1e443a5dc5", null ],
    [ "kernel_precomputed", "class_kernel.html#aa7bce181dce4b32b1d84b0483006d934", null ],
    [ "kernel_rbf", "class_kernel.html#a78f1025eae410c560c8e55845b2fcb3f", null ],
    [ "kernel_sigmoid", "class_kernel.html#a16d668579ecb347c4188f8772ca00547", null ],
    [ "swap_index", "class_kernel.html#adca807c5584bc42fd098cd9eb1f19621", null ],
    [ "coef0", "class_kernel.html#a9b78d78675c9d5094daabf85c1d63b5d", null ],
    [ "degree", "class_kernel.html#a332697fbc977298e3f8701224dbe4bf0", null ],
    [ "gamma", "class_kernel.html#a3a8a0a00a7d58708d6a7c5bc9c872513", null ],
    [ "kernel_function", "class_kernel.html#a575eeb588e8a5c62ff3228a35e255a02", null ],
    [ "kernel_type", "class_kernel.html#a01e78214a5c60876d71ee05fe97f4566", null ],
    [ "x", "class_kernel.html#a725a35660c4309605c2628fa8290ce5f", null ],
    [ "x_square", "class_kernel.html#a97ca8abb41cd6ba8b1553738d59352d5", null ]
];