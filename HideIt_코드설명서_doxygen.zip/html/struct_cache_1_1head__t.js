var struct_cache_1_1head__t =
[
    [ "data", "struct_cache_1_1head__t.html#a630b97ea8171e7e8c1f4ff6c3b12c587", null ],
    [ "len", "struct_cache_1_1head__t.html#af62eb0bc8e61b1889fef2bf7f8a0222b", null ],
    [ "next", "struct_cache_1_1head__t.html#aa152a104ec07250949c234d164f5f3fd", null ],
    [ "prev", "struct_cache_1_1head__t.html#a82b1a4d1a105769f85cce8d51c19860e", null ]
];