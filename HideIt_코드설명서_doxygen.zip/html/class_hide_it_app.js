var class_hide_it_app =
[
    [ "HideItApp", "class_hide_it_app.html#a25b287e17fde1028b896562d9aec209d", null ],
    [ "~HideItApp", "class_hide_it_app.html#a7ed9f1059ff2914a7fea9b4980601e86", null ],
    [ "CreateInstance", "class_hide_it_app.html#a4f97afacfa7f884ebb25b365d7b54ced", null ],
    [ "OnAppInitialized", "class_hide_it_app.html#ab48a46dbf7bfbc40464d7ca2a6412b68", null ],
    [ "OnAppInitializing", "class_hide_it_app.html#a1bb800c07eb3f3681114d3ad2e90c6ec", null ],
    [ "OnAppTerminating", "class_hide_it_app.html#a95f40b0279bd537a7c92bf04b65052f8", null ],
    [ "OnAppWillTerminate", "class_hide_it_app.html#aa24238b490191e31a1e44495f9186768", null ],
    [ "OnBackground", "class_hide_it_app.html#a401ad084aea223293dd21de6bb26e406", null ],
    [ "OnBatteryLevelChanged", "class_hide_it_app.html#a23f8663b71d8c349357ddcc5af0ff24a", null ],
    [ "OnForeground", "class_hide_it_app.html#a17fa8c008dfdf8ede16c30340076ac38", null ],
    [ "OnLowMemory", "class_hide_it_app.html#a74f46c685155afb11356c3308f99af7c", null ],
    [ "OnScreenOff", "class_hide_it_app.html#a194ebdaec407aede77aec536166cab87", null ],
    [ "OnScreenOn", "class_hide_it_app.html#acb0adbbeeddf3d71c01a1ecaf4ddd897", null ]
];