var struct_solver_1_1_solution_info =
[
    [ "obj", "struct_solver_1_1_solution_info.html#adf1d775e9152a7b1742057cd638ed2ae", null ],
    [ "r", "struct_solver_1_1_solution_info.html#a3db948f9e914e1f9976523cfdc7c1bbe", null ],
    [ "rho", "struct_solver_1_1_solution_info.html#a8091f45a336af39e232f3845e25f2266", null ],
    [ "upper_bound_n", "struct_solver_1_1_solution_info.html#a07ab9dc3265855f483922988bdaaf986", null ],
    [ "upper_bound_p", "struct_solver_1_1_solution_info.html#a94c4cb7f402752326cc975ec57a8688f", null ]
];