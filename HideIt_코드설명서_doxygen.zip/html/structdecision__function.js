var structdecision__function =
[
    [ "alpha", "structdecision__function.html#ab79ad1c39d091d4f8ad798abe4223772", null ],
    [ "rho", "structdecision__function.html#ae2aeeaa508803351b22d4454b81cb375", null ]
];