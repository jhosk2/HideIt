var class_hide_it_frame =
[
    [ "HideItFrame", "class_hide_it_frame.html#af7ce52eb89d946385218b91cfc93a106", null ],
    [ "~HideItFrame", "class_hide_it_frame.html#ad9d72885876515a9eb9c90dfeb56d41a", null ],
    [ "OnInitializing", "class_hide_it_frame.html#a8634904e05241fe0b517a86ec4940492", null ],
    [ "OnTerminating", "class_hide_it_frame.html#a31312e076da844a342a7ef8757925e23", null ]
];