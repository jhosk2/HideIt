var class_proxy_sensor =
[
    [ "ProxySensor", "class_proxy_sensor.html#ab6f0509bcde7aa515c6c2a4cf7180887", null ],
    [ "~ProxySensor", "class_proxy_sensor.html#a26bdf3f2477f1ea84db56e4d4ebfc26e", null ],
    [ "OnDataReceived", "class_proxy_sensor.html#a21570507e6392e6e8d98d06997a4e80e", null ],
    [ "OpenCalculator", "class_proxy_sensor.html#a0843719b4dd18b7d0765996c2c078ff8", null ],
    [ "__sensorMgr", "class_proxy_sensor.html#afa7f75c2ad489dd958cf07c8d11196a0", null ],
    [ "isDetected", "class_proxy_sensor.html#a508bdca3572c905679378d23787b0acc", null ]
];