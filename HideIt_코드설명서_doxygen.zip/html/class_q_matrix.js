var class_q_matrix =
[
    [ "~QMatrix", "class_q_matrix.html#a52846254a40a7fa23fa31515ceb99ce1", null ],
    [ "get_Q", "class_q_matrix.html#a87c11086390c81293d2978e042be3d10", null ],
    [ "get_QD", "class_q_matrix.html#af04994d9632b6194f626c431ce93083f", null ],
    [ "swap_index", "class_q_matrix.html#acb4e256ebe3008dff0d4b5414102dbe7", null ]
];