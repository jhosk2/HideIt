var searchData=
[
  ['kernel',['Kernel',['../class_kernel.html',1,'']]]
];
