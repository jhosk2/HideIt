var searchData=
[
  ['x',['x',['../structsvm__problem.html#acddda9b49a8e38bbda079f35c2e18984',1,'svm_problem::x()'],['../class_svm_wrapper.html#abf0dcde4c2d3ec163b487fdf6cc883bc',1,'SvmWrapper::x()'],['../class_kernel.html#a725a35660c4309605c2628fa8290ce5f',1,'Kernel::x()'],['../svm-predict_8c.html#a9a5b72a4065074cac5da07efb80a1e79',1,'x():&#160;svm-predict.c']]],
  ['x_5fsquare',['x_square',['../class_kernel.html#a97ca8abb41cd6ba8b1553738d59352d5',1,'Kernel']]]
];
