var searchData=
[
  ['kernel_5ffunction',['kernel_function',['../class_kernel.html#a575eeb588e8a5c62ff3228a35e255a02',1,'Kernel']]],
  ['kernel_5ftype',['kernel_type',['../structsvm__parameter.html#a4188713ba31fc3d101244a6bcc09a760',1,'svm_parameter::kernel_type()'],['../class_kernel.html#a01e78214a5c60876d71ee05fe97f4566',1,'Kernel::kernel_type()']]],
  ['kernel_5ftype_5ftable',['kernel_type_table',['../svm_8cpp.html#a2812fc7dc5b3db65a9bf7da83e25bb3d',1,'svm.cpp']]]
];
