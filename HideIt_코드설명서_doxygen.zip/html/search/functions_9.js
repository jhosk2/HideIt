var searchData=
[
  ['k_5ffunction',['k_function',['../class_kernel.html#a6ff0d4ac64bf7fba29d2ca3433dd5127',1,'Kernel']]],
  ['kernel',['Kernel',['../class_kernel.html#a25ffaa0c67cc5b8c7fcdb6f97ca1725f',1,'Kernel']]],
  ['kernel_5flinear',['kernel_linear',['../class_kernel.html#a9ccd52d8f291ab38be66944257420a87',1,'Kernel']]],
  ['kernel_5fpoly',['kernel_poly',['../class_kernel.html#af9a74728d70af7ec68947b1e443a5dc5',1,'Kernel']]],
  ['kernel_5fprecomputed',['kernel_precomputed',['../class_kernel.html#aa7bce181dce4b32b1d84b0483006d934',1,'Kernel']]],
  ['kernel_5frbf',['kernel_rbf',['../class_kernel.html#a78f1025eae410c560c8e55845b2fcb3f',1,'Kernel']]],
  ['kernel_5fsigmoid',['kernel_sigmoid',['../class_kernel.html#a16d668579ecb347c4188f8772ca00547',1,'Kernel']]]
];
