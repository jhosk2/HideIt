var searchData=
[
  ['rbf',['RBF',['../svm_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a7e039b006aa5830e8c45a1ccd0c4204f',1,'svm.h']]]
];
