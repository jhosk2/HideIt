var searchData=
[
  ['true',['TRUE',['../_calculate_8h.html#a3e5b8192e7d9ffaf3542f1210aec18ddaa82764c3079aea4e60c80e45befbb839',1,'Calculate.h']]]
];
