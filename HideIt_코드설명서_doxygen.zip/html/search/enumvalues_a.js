var searchData=
[
  ['sigmoid',['SIGMOID',['../svm_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a11c1096689b7d3504dbcc4f61d854883',1,'svm.h']]]
];
