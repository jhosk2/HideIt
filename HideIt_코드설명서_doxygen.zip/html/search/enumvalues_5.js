var searchData=
[
  ['linear',['LINEAR',['../svm_8h.html#adf764cbdea00d65edcd07bb9953ad2b7adc101ebf31c49c2d4b80b7c6f59f22cb',1,'svm.h']]],
  ['lower_5fbound',['LOWER_BOUND',['../class_solver.html#a86c1a7637bc803ef8496c7dbf7f00b03aeb78558e05ec0672378c3e801e866560',1,'Solver']]]
];
