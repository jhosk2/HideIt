var searchData=
[
  ['value',['value',['../structsvm__node.html#a9ca47b8a156238d04213453f3b89e177',1,'svm_node']]],
  ['variable',['Variable',['../class_calculate.html#a75fc03f230ef600e36be8073acc34216',1,'Calculate']]]
];
