var searchData=
[
  ['libsvm_5fversion',['LIBSVM_VERSION',['../svm_8h.html#ac7f5361b69ddd196a885f142b3c1d261',1,'svm.h']]]
];
