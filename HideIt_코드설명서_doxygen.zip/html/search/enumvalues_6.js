var searchData=
[
  ['nu_5fsvc',['NU_SVC',['../svm_8h.html#a06fc87d81c62e9abb8790b6e5713c55baca90881af01036a7221b791eb08d03fc',1,'svm.h']]],
  ['nu_5fsvr',['NU_SVR',['../svm_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9e113c85baa91dc44fe128028e384309',1,'svm.h']]]
];
