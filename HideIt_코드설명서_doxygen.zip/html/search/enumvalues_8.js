var searchData=
[
  ['poly',['POLY',['../svm_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a7d85766d041d397d096dcbc0d7c793fd',1,'svm.h']]],
  ['precomputed',['PRECOMPUTED',['../svm_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a27a6ccce9f5a44692a040b08a6923285',1,'svm.h']]]
];
