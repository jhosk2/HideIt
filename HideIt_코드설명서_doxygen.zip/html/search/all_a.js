var searchData=
[
  ['k_5ffunction',['k_function',['../class_kernel.html#a6ff0d4ac64bf7fba29d2ca3433dd5127',1,'Kernel']]],
  ['kernel',['Kernel',['../class_kernel.html',1,'Kernel'],['../class_kernel.html#a25ffaa0c67cc5b8c7fcdb6f97ca1725f',1,'Kernel::Kernel()']]],
  ['kernel_5ffunction',['kernel_function',['../class_kernel.html#a575eeb588e8a5c62ff3228a35e255a02',1,'Kernel']]],
  ['kernel_5flinear',['kernel_linear',['../class_kernel.html#a9ccd52d8f291ab38be66944257420a87',1,'Kernel']]],
  ['kernel_5fpoly',['kernel_poly',['../class_kernel.html#af9a74728d70af7ec68947b1e443a5dc5',1,'Kernel']]],
  ['kernel_5fprecomputed',['kernel_precomputed',['../class_kernel.html#aa7bce181dce4b32b1d84b0483006d934',1,'Kernel']]],
  ['kernel_5frbf',['kernel_rbf',['../class_kernel.html#a78f1025eae410c560c8e55845b2fcb3f',1,'Kernel']]],
  ['kernel_5fsigmoid',['kernel_sigmoid',['../class_kernel.html#a16d668579ecb347c4188f8772ca00547',1,'Kernel']]],
  ['kernel_5ftype',['kernel_type',['../structsvm__parameter.html#a4188713ba31fc3d101244a6bcc09a760',1,'svm_parameter::kernel_type()'],['../class_kernel.html#a01e78214a5c60876d71ee05fe97f4566',1,'Kernel::kernel_type()']]],
  ['kernel_5ftype_5ftable',['kernel_type_table',['../svm_8cpp.html#a2812fc7dc5b3db65a9bf7da83e25bb3d',1,'svm.cpp']]]
];
