var searchData=
[
  ['data',['data',['../struct_cache_1_1head__t.html#a630b97ea8171e7e8c1f4ff6c3b12c587',1,'Cache::head_t']]],
  ['dbname',['dbName',['../class_cryptor.html#a631efae25eefeee21503de08c1a05f31',1,'Cryptor']]],
  ['decision_5ffunction',['decision_function',['../structdecision__function.html',1,'']]],
  ['decrypt',['Decrypt',['../class_cryptor.html#a82e76152a3351f63ae517664187d5498',1,'Cryptor']]],
  ['degree',['degree',['../structsvm__parameter.html#afef1c4508ec0045c236a3308b0fa5138',1,'svm_parameter::degree()'],['../class_kernel.html#a332697fbc977298e3f8701224dbe4bf0',1,'Kernel::degree()']]],
  ['delete_5fsign',['DELETE_SIGN',['../_calculator_form_8cpp.html#a454db45292332cab043f74d3acefa482',1,'CalculatorForm.cpp']]],
  ['deleteitem',['DeleteItem',['../class_folder_browser.html#aba37eeb02c62176b3f45c355bbc3dbab',1,'FolderBrowser']]],
  ['do_5fshrinking',['do_shrinking',['../class_solver.html#ad3f6665a1ca590e56b3d51f8ddcc347c',1,'Solver::do_shrinking()'],['../class_solver___n_u.html#a6670a539940f4efdc40d2c9e75a9da1b',1,'Solver_NU::do_shrinking()']]],
  ['dot',['dot',['../class_kernel.html#af258ecfb8ca0182e6a79c06291586e5b',1,'Kernel::dot()'],['../_calculator_form_8cpp.html#a5f2b2f460e2ebcf757c348d74ed9ef68',1,'DOT():&#160;CalculatorForm.cpp']]]
];
