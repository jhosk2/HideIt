var searchData=
[
  ['g',['G',['../class_solver.html#ad8ab27068f2e045591970aae1201afe9',1,'Solver']]],
  ['g_5fbar',['G_bar',['../class_solver.html#a89e58cf39a0415c9032b8ec2f4575dcc',1,'Solver']]],
  ['gamma',['gamma',['../structsvm__parameter.html#a91667b90506e171482b5fc619377110d',1,'svm_parameter::gamma()'],['../class_kernel.html#a3a8a0a00a7d58708d6a7c5bc9c872513',1,'Kernel::gamma()']]]
];
