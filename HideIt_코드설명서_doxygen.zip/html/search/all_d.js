var searchData=
[
  ['narrowstring',['NarrowString',['../class_calculator_form.html#a861aa95341240a0d98db563acc753bca',1,'CalculatorForm']]],
  ['next',['next',['../struct_cache_1_1head__t.html#aa152a104ec07250949c234d164f5f3fd',1,'Cache::head_t']]],
  ['next_5fbuffer',['next_buffer',['../class_s_v_r___q.html#acbdbde823b714d30097648c9dc109524',1,'SVR_Q']]],
  ['no_5fresult',['NO_RESULT',['../_calculator_form_8cpp.html#a364808cb06bdb87add9aa111ff5ae3d4',1,'CalculatorForm.cpp']]],
  ['none',['NONE',['../_calculator_form_8cpp.html#a7b20f1b443e093d5ec5e990e73b47232',1,'CalculatorForm.cpp']]],
  ['nr_5fclass',['nr_class',['../structsvm__model.html#a5af6e0cfb063e8aac03c99aa9d319116',1,'svm_model']]],
  ['nr_5fweight',['nr_weight',['../structsvm__parameter.html#a44014738d1db5444f7f9a1ebf74e4214',1,'svm_parameter']]],
  ['nsv',['nSV',['../structsvm__model.html#a1d342c9b9e5e4a6377862e13123a25ef',1,'svm_model']]],
  ['nu',['nu',['../structsvm__parameter.html#a4c20c566cb61d5808e8cabd7adbc35c1',1,'svm_parameter']]],
  ['nu_5fsvc',['NU_SVC',['../svm_8h.html#a06fc87d81c62e9abb8790b6e5713c55baca90881af01036a7221b791eb08d03fc',1,'svm.h']]],
  ['nu_5fsvr',['NU_SVR',['../svm_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9e113c85baa91dc44fe128028e384309',1,'svm.h']]],
  ['nullfunc',['nullfunc',['../_calculator_form_8cpp.html#ab961cf377425a7b81fd62afffd8e89e1',1,'CalculatorForm.cpp']]],
  ['num_5feng_5fbuttons',['NUM_ENG_BUTTONS',['../_calculator_form_8cpp.html#a07008d1eb5c7e6f7b9e3459e232346a7',1,'CalculatorForm.cpp']]],
  ['num_5fnormal_5fbuttons',['NUM_NORMAL_BUTTONS',['../_calculator_form_8cpp.html#a5231d80877ae945c17f323f927dd1bcf',1,'CalculatorForm.cpp']]]
];
