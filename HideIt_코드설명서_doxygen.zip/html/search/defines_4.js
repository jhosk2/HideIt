var searchData=
[
  ['m_5fe',['M_E',['../_calculate_8cpp.html#a9bf5d952c5c93c70f9e66c9794d406c9',1,'Calculate.cpp']]],
  ['m_5fpi',['M_PI',['../_calculate_8cpp.html#ae71449b1cc6e6250b91f539153a7a0d3',1,'Calculate.cpp']]],
  ['malloc',['Malloc',['../svm_8cpp.html#a9191047fd644a5f519152ecb4aa60357',1,'svm.cpp']]],
  ['max',['MAX',['../_calculate_8cpp.html#a392fb874e547e582e9c66a08a1f23326',1,'Calculate.cpp']]]
];
