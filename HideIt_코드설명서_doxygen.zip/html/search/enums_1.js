var searchData=
[
  ['filetype',['filetype',['../_folder_browser_8h.html#af547d73b85f475c4abfafdb76bf0c301',1,'FolderBrowser.h']]]
];
