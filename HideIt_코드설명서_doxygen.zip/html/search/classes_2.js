var searchData=
[
  ['decision_5ffunction',['decision_function',['../structdecision__function.html',1,'']]]
];
