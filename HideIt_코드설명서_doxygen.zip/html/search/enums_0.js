var searchData=
[
  ['bool',['BOOL',['../_calculate_8h.html#a3e5b8192e7d9ffaf3542f1210aec18dd',1,'Calculate.h']]],
  ['buttonactionid',['ButtonActionId',['../class_calculator_form.html#a7f0486405077c1eaee1faa73e631a67f',1,'CalculatorForm']]]
];
