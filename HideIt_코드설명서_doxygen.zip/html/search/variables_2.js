var searchData=
[
  ['blocksize',['blocksize',['../_cryptor_8h.html#ac79f210bfc653c2bd32cd58cd1836018',1,'Cryptor.h']]],
  ['buffer',['buffer',['../class_s_v_r___q.html#a294d15ab4ee01b92c960a604afbd6f9f',1,'SVR_Q']]]
];
