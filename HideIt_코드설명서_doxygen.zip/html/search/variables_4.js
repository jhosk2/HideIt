var searchData=
[
  ['data',['data',['../struct_cache_1_1head__t.html#a630b97ea8171e7e8c1f4ff6c3b12c587',1,'Cache::head_t']]],
  ['dbname',['dbName',['../class_cryptor.html#a631efae25eefeee21503de08c1a05f31',1,'Cryptor']]],
  ['degree',['degree',['../structsvm__parameter.html#afef1c4508ec0045c236a3308b0fa5138',1,'svm_parameter::degree()'],['../class_kernel.html#a332697fbc977298e3f8701224dbe4bf0',1,'Kernel::degree()']]],
  ['delete_5fsign',['DELETE_SIGN',['../_calculator_form_8cpp.html#a454db45292332cab043f74d3acefa482',1,'CalculatorForm.cpp']]],
  ['dot',['DOT',['../_calculator_form_8cpp.html#a5f2b2f460e2ebcf757c348d74ed9ef68',1,'CalculatorForm.cpp']]]
];
