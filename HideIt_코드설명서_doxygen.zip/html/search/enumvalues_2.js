var searchData=
[
  ['false',['FALSE',['../_calculate_8h.html#a3e5b8192e7d9ffaf3542f1210aec18ddaa1e095cc966dbecf6a0d8aad75348d1a',1,'Calculate.h']]],
  ['free',['FREE',['../class_solver.html#a86c1a7637bc803ef8496c7dbf7f00b03a904f6af2170b6f900fbd3d46cd055c76',1,'Solver']]]
];
