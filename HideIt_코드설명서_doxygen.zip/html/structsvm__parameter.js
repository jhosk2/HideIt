var structsvm__parameter =
[
    [ "C", "structsvm__parameter.html#af4f905a3f7d589d86964289af3c9d812", null ],
    [ "cache_size", "structsvm__parameter.html#a00286b7e0767e45d68ac7abceb60c821", null ],
    [ "coef0", "structsvm__parameter.html#a3ab3555a96a578bea6e5285a5db0a4db", null ],
    [ "degree", "structsvm__parameter.html#afef1c4508ec0045c236a3308b0fa5138", null ],
    [ "eps", "structsvm__parameter.html#a1feab5a4e0d5842a20e544f3f944f841", null ],
    [ "gamma", "structsvm__parameter.html#a91667b90506e171482b5fc619377110d", null ],
    [ "kernel_type", "structsvm__parameter.html#a4188713ba31fc3d101244a6bcc09a760", null ],
    [ "nr_weight", "structsvm__parameter.html#a44014738d1db5444f7f9a1ebf74e4214", null ],
    [ "nu", "structsvm__parameter.html#a4c20c566cb61d5808e8cabd7adbc35c1", null ],
    [ "p", "structsvm__parameter.html#a3b60d7ce96137a64caca81095d1a188b", null ],
    [ "probability", "structsvm__parameter.html#afac0ef02879d7e27e17ac2a75115a7d9", null ],
    [ "shrinking", "structsvm__parameter.html#afdbccdf6a24be650d75804b783edc347", null ],
    [ "svm_type", "structsvm__parameter.html#a3afb37272180a903df05f7b649b338f4", null ],
    [ "weight", "structsvm__parameter.html#afff750f99180b5ddf735404496b6c196", null ],
    [ "weight_label", "structsvm__parameter.html#a06753922bb0282240f35ae7683f8d69a", null ]
];