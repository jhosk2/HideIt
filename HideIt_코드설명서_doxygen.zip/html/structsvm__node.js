var structsvm__node =
[
    [ "index", "structsvm__node.html#aa733ca75ee5a5c0f36af5ddb4c6394d9", null ],
    [ "value", "structsvm__node.html#a9ca47b8a156238d04213453f3b89e177", null ]
];