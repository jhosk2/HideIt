var class_s_v_r___q =
[
    [ "SVR_Q", "class_s_v_r___q.html#a348978e0cce4c0bf503dc825241eb4ff", null ],
    [ "~SVR_Q", "class_s_v_r___q.html#a2a8efdc1fef68cc5bc9d0d2669d24e36", null ],
    [ "get_Q", "class_s_v_r___q.html#aba55078d17e7815f093ffa154f3cee9d", null ],
    [ "get_QD", "class_s_v_r___q.html#ac22ed5ce1b0bf6a900c3c8d631e77d76", null ],
    [ "k_function", "class_s_v_r___q.html#a6ff0d4ac64bf7fba29d2ca3433dd5127", null ],
    [ "swap_index", "class_s_v_r___q.html#a9d3884f0c68f4ce18d47570e4a203405", null ],
    [ "buffer", "class_s_v_r___q.html#a294d15ab4ee01b92c960a604afbd6f9f", null ],
    [ "cache", "class_s_v_r___q.html#acb75212bdcc8128a28b35601f8265828", null ],
    [ "index", "class_s_v_r___q.html#a29e769c577358f518182ba3cbe255817", null ],
    [ "kernel_function", "class_s_v_r___q.html#a575eeb588e8a5c62ff3228a35e255a02", null ],
    [ "l", "class_s_v_r___q.html#aa3420dab3d0b1eabdc0614c71321ab3c", null ],
    [ "next_buffer", "class_s_v_r___q.html#acbdbde823b714d30097648c9dc109524", null ],
    [ "QD", "class_s_v_r___q.html#aaa4a8b37dbc15610de7fe46df8874e25", null ],
    [ "sign", "class_s_v_r___q.html#a0255ad0a00ef589c69adc19a06527dfc", null ]
];