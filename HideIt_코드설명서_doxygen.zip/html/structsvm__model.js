var structsvm__model =
[
    [ "free_sv", "structsvm__model.html#a2ae57ce1fa43497d151aff26c21a13a1", null ],
    [ "l", "structsvm__model.html#ab858d7eed0bd3cc4c33c094872643d0a", null ],
    [ "label", "structsvm__model.html#ac66d192809e92b95875bdf8ebb749060", null ],
    [ "nr_class", "structsvm__model.html#a5af6e0cfb063e8aac03c99aa9d319116", null ],
    [ "nSV", "structsvm__model.html#a1d342c9b9e5e4a6377862e13123a25ef", null ],
    [ "param", "structsvm__model.html#a95f43f398a173e63d0ce26911d0a9273", null ],
    [ "probA", "structsvm__model.html#adf5f28fcdd3ca1c5b23c1f6167710a04", null ],
    [ "probB", "structsvm__model.html#a73ba8feaaf3c2c38c6bb81f7bcb5809e", null ],
    [ "rho", "structsvm__model.html#a16e4dea1508f93ece4384ec35c991887", null ],
    [ "SV", "structsvm__model.html#a96da6fe173a7150dae95bf55d5539e45", null ],
    [ "sv_coef", "structsvm__model.html#a978084d722ac886100ffcc35fc931143", null ],
    [ "sv_indices", "structsvm__model.html#add7f649bf78428c38a282ed8776fa433", null ]
];