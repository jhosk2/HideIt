var class_text_viewer_form =
[
    [ "TextViewerForm", "class_text_viewer_form.html#ada62cff12c9cfa681225802c67533d9d", null ],
    [ "~TextViewerForm", "class_text_viewer_form.html#a99d3e7fdee7c11c98b553d37bccbd561", null ],
    [ "Initialize", "class_text_viewer_form.html#a4ad26f2e53b8f74ce5d3faefc551b2e6", null ],
    [ "LoadText", "class_text_viewer_form.html#a42a0c06dc751be74e60b62406d44b90d", null ],
    [ "OnActionPerformed", "class_text_viewer_form.html#ae70d1e122343faa59719d604d1ae12b0", null ],
    [ "OnFormBackRequested", "class_text_viewer_form.html#a1e6b94e7f974811b9ecc45dc6a7893ca", null ],
    [ "OnInitializing", "class_text_viewer_form.html#a1174b7f39c5eaf5bc70598c54df20fb4", null ],
    [ "OnSceneActivatedN", "class_text_viewer_form.html#a71299da85593d79746ce82dae99b56d3", null ],
    [ "OnSceneDeactivated", "class_text_viewer_form.html#af70565ab8d8365244043d0b9e390026b", null ],
    [ "OnTerminating", "class_text_viewer_form.html#a152bcf154536f98c405bc8f35f545ca6", null ],
    [ "ReadFile", "class_text_viewer_form.html#a29ab38eb99aee639cd6a9d3f1d2aa6dd", null ],
    [ "__pTizenBitmap", "class_text_viewer_form.html#ab424cff2021ff464552b4185579209f1", null ],
    [ "filePath", "class_text_viewer_form.html#a5cea61f0286c8cda983e61760e9d5f47", null ],
    [ "popup", "class_text_viewer_form.html#afd589dc0e964f2615dfc9414ffffdb44", null ],
    [ "pTextBox", "class_text_viewer_form.html#af19e24e33e90149750d852ce35da7b38", null ],
    [ "sensorProxy", "class_text_viewer_form.html#a5235dd45fbd19e2a6c64949ee9803829", null ]
];