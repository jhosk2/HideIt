var class_cache =
[
    [ "head_t", "struct_cache_1_1head__t.html", "struct_cache_1_1head__t" ],
    [ "Cache", "class_cache.html#a2823f543d4f9b92c29472b904961afe1", null ],
    [ "~Cache", "class_cache.html#af8b171a6c49d88d3ba179477484b9d48", null ],
    [ "get_data", "class_cache.html#aca49263fb34641e208884cc223b25317", null ],
    [ "lru_delete", "class_cache.html#ab83abc6ded621fa2575e3a44421e0cb4", null ],
    [ "lru_insert", "class_cache.html#a51e5ffc28e2ec6662ae13ab78ccc2243", null ],
    [ "swap_index", "class_cache.html#aaff2dc955f9492c044c98a5f09cfddcc", null ],
    [ "head", "class_cache.html#aaf3674e8de1e3896dba64b4caac79f0a", null ],
    [ "l", "class_cache.html#a8f5881aa763cb4af5cfb7b6bda0cff35", null ],
    [ "lru_head", "class_cache.html#a91fc6bd9c69ed37e8e0499da8d47794e", null ],
    [ "size", "class_cache.html#af50a89d0734a160cf812384df64599f9", null ]
];