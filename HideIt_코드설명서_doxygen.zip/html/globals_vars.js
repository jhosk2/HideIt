var globals_vars =
[
    [ "a", "globals_vars.html", null ],
    [ "b", "globals_vars_b.html", null ],
    [ "d", "globals_vars_d.html", null ],
    [ "e", "globals_vars_e.html", null ],
    [ "f", "globals_vars_f.html", null ],
    [ "i", "globals_vars_i.html", null ],
    [ "k", "globals_vars_k.html", null ],
    [ "l", "globals_vars_l.html", null ],
    [ "m", "globals_vars_m.html", null ],
    [ "n", "globals_vars_n.html", null ],
    [ "o", "globals_vars_o.html", null ],
    [ "p", "globals_vars_p.html", null ],
    [ "r", "globals_vars_r.html", null ],
    [ "s", "globals_vars_s.html", null ],
    [ "t", "globals_vars_t.html", null ],
    [ "x", "globals_vars_x.html", null ]
];