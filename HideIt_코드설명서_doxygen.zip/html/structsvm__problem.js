var structsvm__problem =
[
    [ "l", "structsvm__problem.html#a4350eb6820f0d6126bffb6264cec65b3", null ],
    [ "x", "structsvm__problem.html#acddda9b49a8e38bbda079f35c2e18984", null ],
    [ "y", "structsvm__problem.html#a59dec12ff090571bc9592ba9fb306780", null ]
];