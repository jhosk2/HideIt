var class_svm_wrapper =
[
    [ "SvmWrapper", "class_svm_wrapper.html#a81d04cd6c08b9cb263c1f4a7151dd572", null ],
    [ "GetModelPath", "class_svm_wrapper.html#aff945103751fb220525ddd4fd102bda1", null ],
    [ "GetOutputPath", "class_svm_wrapper.html#a6401e2559203adaff909ba3862d91ceb", null ],
    [ "init", "class_svm_wrapper.html#af06622d63ce23b77ac29aa29298110d7", null ],
    [ "predict", "class_svm_wrapper.html#a2f3adec2bc81b6c37416156465485e9c", null ],
    [ "predictt", "class_svm_wrapper.html#a454766365e910aa34b39dbba67d5caaf", null ],
    [ "LANDREVERSE", "class_svm_wrapper.html#a110ad1be7ec6ee74987b023d96b1b9f2", null ],
    [ "LANDSCAPE", "class_svm_wrapper.html#a00905fc7b3ee662dc4ae5aabb5e2aadc", null ],
    [ "max_line_len", "class_svm_wrapper.html#a6921acb6aa7fdaf8a784c4e9df839ad1", null ],
    [ "max_nr_attr", "class_svm_wrapper.html#ac3f77511deba1c80caa8e7150097d8d6", null ],
    [ "model", "class_svm_wrapper.html#a2acad681f29bd8269c5b11aa568222ec", null ],
    [ "PORTRAIT", "class_svm_wrapper.html#a15817ef9250668698357b03178838c63", null ],
    [ "predict_probability", "class_svm_wrapper.html#a18cae78dd4b43d0dc1f2e4d2446b3568", null ],
    [ "x", "class_svm_wrapper.html#abf0dcde4c2d3ec163b487fdf6cc883bc", null ]
];